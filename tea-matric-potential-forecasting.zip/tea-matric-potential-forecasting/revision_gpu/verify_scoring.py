import ast,json,tempfile,argparse
from pathlib import Path
from types import SimpleNamespace
import numpy as np,pandas as pd
p=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--input-dir',type=Path,required=True);args=parser.parse_args();inputs=args.input_dir.expanduser().resolve()
tree=ast.parse((p/'run_gpu_revision.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='report_predictions')
source=ast.Module(body=[node],type_ignores=[])
all_orig=pd.read_csv(inputs/'evaluation_origins.csv');all_ref=pd.read_csv(inputs/'eligible_endpoint_reference.csv')
data=dict(np.load(inputs/'training_windows.npz',allow_pickle=False))
# Use all origins so the check catches horizon-specific endpoint eligibility.
result={}
with tempfile.TemporaryDirectory() as temp:
 env=dict(np=np,pd=pd,orig=all_orig,ref=all_ref,data=data,out=Path(temp))
 exec(compile(source,'runner_scoring','exec'),env)
 for name,key in [('paired_perfect','evaluation'),('individual_TEROS21_P3_matric_kPa','evaluation_TEROS21_P3_matric_kPa'),('individual_TEROS21_P5_matric_kPa','evaluation_TEROS21_P5_matric_kPa')]:
  forecast=data[key][:,336:].copy()
  env['report_predictions'](forecast,name,0)
  metrics=pd.read_csv(Path(temp)/(name+'_seed0_endpoint_metrics.csv'))
  # Paired reference has original float64 precision, NPZ is float32.
  tolerance=0.0001 if name=='paired_perfect' else 1e-10
  assert metrics.MAE.max()<tolerance,metrics
  for row in metrics.itertuples():
   expected=len(all_ref[(all_ref.split==row.split)&(all_ref.horizon_h==row.horizon_h)])
   assert row.n==expected,(row.n,expected)
  endpoints=pd.read_csv(Path(temp)/(name+'_seed0_eligible_endpoints.csv.gz'))
  if name.startswith('individual'):
   assert set(endpoints.sensor_depth_cm)==({5} if 'P3' in name else {20})
  result[name]=metrics.to_dict(orient='records')
print(json.dumps({'status':'passed','checks':'Perfect forecasts scored against correct paired/individual observations; all endpoint eligibility counts match; sensor depths preserved','metrics':result},indent=2))
