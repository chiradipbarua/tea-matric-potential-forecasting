# Revision experiment runner

`run_gpu_revision.py` runs the experiments added during revision: Chronos-2 LoRA (rank 16) with fixed seeds 13, 42, 2026, 3407 and 9001, target-only GRU controls with 168- and 336-h contexts, and frozen Chronos-2 forecasts for individual sensor channels. Checkpoints are selected on validation data only. `verify_scoring.py` recomputes the reported metrics from the runner outputs.

Input files (not included; available from the corresponding author on request): `training_windows.npz` (336-h histories and 72-h futures), `evaluation_origins.csv`, `eligible_endpoint_reference.csv` and `sensor_installation_confirmed.json`.

Environment used: Python 3.11.15, PyTorch 2.11.0+cu128, chronos-forecasting 2.2.2, PEFT 0.19.1, Transformers 4.57.6; `amazon/chronos-2` revision `29ec3766d36d6f73f0696f85560a422f50e8498c` (cached locally; offline mode is the default).

```bash
python run_gpu_revision.py --input-dir /path/to/inputs --task check --output /path/to/results
python verify_scoring.py --input-dir /path/to/inputs
```

Available tasks: `check`, `preflight`, `smoke`, `lora`, `gru` and `individual_chronos`.
