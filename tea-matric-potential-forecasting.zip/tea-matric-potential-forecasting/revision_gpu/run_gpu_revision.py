"""Revision-stage GPU sensitivities. Fixed seeds; never selects on test results.
Run in the ORIGINAL Chronos environment. See README before execution.
This new runner is not the unavailable original experiment source.
"""
from pathlib import Path
import argparse,json,time,random,inspect,importlib.metadata,gc,hashlib,sys,platform,os
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--task',choices=['check','preflight','smoke','lora','gru','individual_chronos'],default='check');parser.add_argument('--input-dir',type=Path,required=True);parser.add_argument('--model',default='amazon/chronos-2');parser.add_argument('--output',default=str(P/'gpu_results_v3'));parser.add_argument('--seeds',nargs='+',type=int,default=[13,42,2026,3407,9001]);parser.add_argument('--inference-batch-size',type=int,default=32);args=parser.parse_args()
if args.inference_batch_size<1:parser.error('--inference-batch-size must be positive')
RUNNER_VERSION='3.0.0'
if args.task=='smoke':args.output=str(Path(args.output)/'smoke_only')
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
def note(message):print(time.strftime('[%H:%M:%S] ')+str(message),flush=True)
def write_json(path,value):
 path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,default=str),encoding='utf-8');tmp.replace(path)
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
INPUT=args.input_dir.expanduser().resolve()
note('Runner '+RUNNER_VERSION+' | task='+args.task);data={k:v for k,v in np.load(INPUT/'training_windows.npz',allow_pickle=False).items()};orig=pd.read_csv(INPUT/'evaluation_origins.csv');ref=pd.read_csv(INPUT/'eligible_endpoint_reference.csv');out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
assert data['train'].shape==(1844,408) and data['selection'].shape==(213,408)
assert np.isfinite(data['train']).all() and np.isfinite(data['selection']).all() and np.isfinite(data['evaluation'][:,:336]).all()
assert len(orig)==len(data['evaluation']) and orig.origin_id.is_unique
assert not ref.duplicated(['origin_id','horizon_h']).any()
for channel in ['TEROS21_P3_matric_kPa','TEROS21_P5_matric_kPa']:
 assert data['evaluation_'+channel].shape==data['evaluation'].shape
 assert np.isfinite(data['evaluation_'+channel][:,:336]).all()
if not np.allclose(data['evaluation'],(data['evaluation_TEROS21_P3_matric_kPa']+data['evaluation_TEROS21_P5_matric_kPa'])/2,equal_nan=True,atol=1e-4):
 raise RuntimeError('Paired target differs from the P3/P5 arithmetic mean')
metadata=json.loads((INPUT/'sensor_installation_confirmed.json').read_text(encoding='utf-8'))
write_json(out/'sensor_installation_confirmed.json',metadata)
protocol=dict(runner_version=RUNNER_VERSION,runner_sha256=digest(__file__),task=args.task,
 input_hashes={f:digest(INPUT/f) for f in ['training_windows.npz','evaluation_origins.csv','eligible_endpoint_reference.csv','sensor_installation_confirmed.json']},
 context_hours=336,prediction_hours=72,inference_batch_size=args.inference_batch_size,
 lora_steps=1000,lora_rank=16,lora_alpha=32,lora_dropout=.05,lora_lr=1e-5,lora_batch=4,lora_accumulation=8,
 protocol='Revision-stage controlled sensitivity; validation-only selection; all fixed seeds reported',
 sensor_depths_cm={'P3':5,'P5':20},paired_target='Equal-weight arithmetic mean of matric potential at 5 and 20 cm')
if args.task=='check':
 print('Numeric input checks passed:',{k:v.shape for k,v in data.items()});print('Sensor depths: P3=5 cm, P5=20 cm; both plots. No field calibration.');print('GPU execution is a separate step.');raise SystemExit(0)
import torch
from torch import nn
from torch.utils.data import DataLoader,TensorDataset
if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required for this runner')
device='cuda'
versions={}
for package in ['numpy','pandas','torch','chronos-forecasting','peft','transformers','accelerate','huggingface-hub']:
 try:versions[package]=importlib.metadata.version(package)
 except importlib.metadata.PackageNotFoundError:versions[package]='NOT INSTALLED'
environment=dict(python=sys.version,platform=platform.platform(),packages=versions,gpu=torch.cuda.get_device_name(0),
 cuda_build=torch.version.cuda,total_GPU_bytes=torch.cuda.get_device_properties(0).total_memory,bf16_supported=torch.cuda.is_bf16_supported(),
 seeds=args.seeds,runner_version=RUNNER_VERSION)
write_json(out/('environment_'+args.task+'.json'),environment)
note('GPU: '+environment['gpu']+' | VRAM %.2f GiB'%(environment['total_GPU_bytes']/1024**3))
if args.task in ['preflight','smoke','lora'] and not environment['bf16_supported']:
 raise RuntimeError('Original LoRA protocol uses BF16; device reports it unavailable. Do not silently change precision.')
def guard_protocol():
 manifest=out/('protocol_'+args.task+'.json')
 if manifest.exists() and json.loads(manifest.read_text(encoding='utf-8'))!=protocol:
  raise RuntimeError('Output folder contains a different protocol/model/input version. Use a new --output folder.')
 write_json(manifest,protocol)
 write_json(out/('requested_seeds_'+args.task+'.json'),args.seeds)
def completed(name,seed):
 marker=out/(name+'_seed'+str(seed)+'_COMPLETE.json')
 if marker.exists():
  item=json.loads(marker.read_text(encoding='utf-8'))
  if all((out/f).is_file() and digest(out/f)==value for f,value in item['files'].items()):
   note('Skipping completed '+name+' seed '+str(seed));return True
  raise RuntimeError('Completed-run output is missing or changed: '+str(marker))
 return False
def mark_completed(name,seed,extras=()):
 paths=[out/(name+'_seed'+str(seed)+'_full_paths.csv.gz'),out/(name+'_seed'+str(seed)+'_endpoint_metrics.csv')]+list(extras)
 write_json(out/(name+'_seed'+str(seed)+'_COMPLETE.json'),dict(seed=seed,model=name,files={str(p.relative_to(out)):digest(p) for p in paths}))
def summarize():
 files=list(out.glob('*_endpoint_metrics.csv'))
 if files:
  d=pd.concat([pd.read_csv(f) for f in files]);d.to_csv(out/'all_seed_metrics.csv',index=False)
  d.groupby(['model','split','horizon_h'])[['MAE','RMSE','Bias']].agg(['mean','std','min','max']).to_csv(out/'seed_variability_summary.csv')
  d.groupby(['model','split','horizon_h']).seed.nunique().to_csv(out/'completed_seed_counts.csv')

def seedall(s):
 random.seed(s);np.random.seed(s);torch.manual_seed(s);torch.cuda.manual_seed_all(s)
 torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True

def report_predictions(pred,name,seed):
 rows=[]
 for i,r in orig.iterrows():
  for j in range(72):
   row=dict(origin_id=r.origin_id,origin_timestamp_IST=r.origin_timestamp_IST,plot_id=r.plot_id,split=r.split,forecast_step_h=j+1,seed=seed,model=name)
   if pred.ndim==3:row.update(q10_kPa=float(pred[i,j,0]),q50_kPa=float(pred[i,j,1]),q90_kPa=float(pred[i,j,2]))
   else:row['q50_kPa']=float(pred[i,j])
   if name.startswith('individual_'):row['sensor_depth_cm']=5 if 'P3_' in name else 20
   row['target_definition']='Individual sensor' if name.startswith('individual_') else 'Arithmetic mean: P3 at 5 cm and P5 at 20 cm'
   rows.append(row)
 d=pd.DataFrame(rows);d.to_csv(out/f'{name}_seed{seed}_full_paths.csv.gz',index=False,compression='gzip')
 q=d[d.forecast_step_h.isin([24,48,72])].rename(columns={'forecast_step_h':'horizon_h'}).merge(ref[['origin_id','horizon_h','observed_kPa']],on=['origin_id','horizon_h'],validate='one_to_one')
 if name.startswith('individual_'):
  col=name[len('individual_'):];idx=orig.reset_index().set_index('origin_id')['index'];q['observed_kPa']=[data['evaluation_'+col][int(idx[o]),335+int(h)] for o,h in zip(q.origin_id,q.horizon_h)];q=q.dropna(subset=['observed_kPa','q50_kPa'])
 q=q[np.isfinite(q.observed_kPa)&np.isfinite(q.q50_kPa)].copy()
 q.to_csv(out/f'{name}_seed{seed}_eligible_endpoints.csv.gz',index=False,compression='gzip')
 met=[]
 for (sp,h),g in q.groupby(['split','horizon_h']):
  e=g.q50_kPa-g.observed_kPa;met.append(dict(model=name,seed=seed,split=sp,horizon_h=h,n=len(g),MAE=float(abs(e).mean()),RMSE=float(np.sqrt(np.mean(e**2))),Bias=float(e.mean())))
 pd.DataFrame(met).to_csv(out/f'{name}_seed{seed}_endpoint_metrics.csv',index=False)

def chronos_predict(pipe,x):
 forecasts=[]
 pipe.model.eval()
 for i in range(0,len(x),args.inference_batch_size):
  inputs=[torch.tensor(a[None,:],dtype=torch.float32) for a in x[i:i+args.inference_batch_size]]
  qs,_=pipe.predict_quantiles(inputs,prediction_length=72,quantile_levels=[.1,.5,.9],context_length=336,batch_size=args.inference_batch_size)
  if len(qs)!=len(inputs):raise RuntimeError('Unexpected number of forecast tensors')
  for q in qs:
   if tuple(q.shape)!=(1,72,3):raise RuntimeError('Unexpected quantile shape: '+str(tuple(q.shape)))
   a=q[0].detach().float().cpu().numpy()
   if not np.isfinite(a).all():raise RuntimeError('Model returned non-finite predictions')
   forecasts.append(a)
  if i==0 or (i//args.inference_batch_size+1)%10==0 or i+args.inference_batch_size>=len(x):note('Forecast origins '+str(min(i+args.inference_batch_size,len(x)))+'/'+str(len(x)))
 return np.stack(forecasts)

if args.task in ['preflight','smoke','lora','individual_chronos']:
 from chronos import Chronos2Pipeline
 from peft import LoraConfig
 from transformers import TrainerCallback,TrainingArguments
 from huggingface_hub import snapshot_download
 env={k:importlib.metadata.version(k) for k in ['torch','chronos-forecasting','peft','transformers']};env['gpu']=torch.cuda.get_device_name();env['model_source']=args.model;env['protocol']='Revision stage; report every seed; original trainer source unavailable'
 candidate=Path(args.model).expanduser()
 if candidate.is_dir():model_path=candidate.resolve()
 else:
  try:model_path=Path(snapshot_download(args.model,local_files_only=True)).resolve()
  except Exception as exc:raise RuntimeError('Original cached Chronos model is unavailable. Supply --model with its local snapshot directory. No model was downloaded.') from exc
 note('Loading cached model: '+str(model_path))
 pipe=Chronos2Pipeline.from_pretrained(str(model_path),device_map='cuda',local_files_only=True)
 protocol['resolved_model_path']=str(model_path);protocol['model_config_sha256']=digest(model_path/'config.json')
 protocol['model_snapshot_id']=model_path.name if model_path.parent.name=='snapshots' else None
 protocol['packages']=versions
 guard_protocol()
 write_json(out/('model_source_'+args.task+'.json'),{k:v for k,v in protocol.items() if k.startswith('model_') or k=='resolved_model_path'})
 try:
  for name,object_ in [('chronos_fit',pipe.fit),('chronos_predict_quantiles',pipe.predict_quantiles)]:
   (out/(name+'_source.py')).write_text(inspect.getsource(object_),encoding='utf-8')
  from chronos.chronos2.dataset import Chronos2Dataset
  (out/'chronos_dataset_source.py').write_text(inspect.getsource(Chronos2Dataset),encoding='utf-8')
 except (OSError,TypeError):note('Installed source extraction unavailable; package versions retained')
 env['resolved_commit_hash']=getattr(pipe.model.config,'_commit_hash',None);env['base_parameters']=sum(p.numel() for p in pipe.model.parameters());env['fit_signature']=str(inspect.signature(pipe.fit));env.update(environment);env['resolved_model_path']=str(model_path);write_json(out/('chronos_environment_'+args.task+'.json'),env)
 if args.task=='preflight':
  required=['finetune_mode','lora_config','min_past','callbacks']
  missing=[k for k in required if k not in inspect.signature(pipe.fit).parameters]
  if missing:raise RuntimeError('Unsupported installed Chronos fit API; missing '+str(missing))
  if 'eval_strategy' not in inspect.signature(TrainingArguments).parameters:raise RuntimeError('Installed Transformers does not support eval_strategy')
  prediction=chronos_predict(pipe,data['selection'][:2,:336]);np.save(out/'preflight_validation_forecasts.npy',prediction)
  note('PREFLIGHT PASSED: offline model load, CUDA inference and quantile shape (2,72,3).');raise SystemExit(0)
 if args.task=='individual_chronos':
  for channel in ['TEROS21_P3_matric_kPa','TEROS21_P5_matric_kPa']:
   name='individual_'+channel
   if completed(name,0):continue
   note('Individual-channel forecasts: '+channel+' depth '+('5 cm' if 'P3_' in channel else '20 cm'))
   x=data['evaluation_'+channel][:,:336];valid=np.isfinite(x).all(axis=1)
   pred=np.full((len(x),72,3),np.nan,dtype=np.float32);pred[valid]=chronos_predict(pipe,x[valid]);report_predictions(pred,name,0);mark_completed(name,0);summarize()
  # These paths need scoring against each sensor's future observations, not paired reference.
  note('Completed individual_chronos. Return gpu_results_v3.');raise SystemExit(0)
 if 'finetune_mode' not in inspect.signature(pipe.fit).parameters:raise RuntimeError('Original Chronos2Pipeline.fit API is required')
 class AuditCallback(TrainerCallback):
  def __init__(self,path):self.path=path
  def on_train_begin(self,args,state,control,model=None,**kwargs):
   values=dict(trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),total_parameters=sum(p.numel() for p in model.parameters()),training_arguments=args.to_dict())
   write_json(self.path,values)
   if values['trainable_parameters']!=2413824:raise RuntimeError('Unexpected adapter parameter count: '+str(values['trainable_parameters'])+'; expected 2413824. Inspect original model/config.')
  def on_log(self,args,state,control,logs=None,**kwargs):
   if logs:note('Training step '+str(state.global_step)+' '+json.dumps(logs,default=str))
  def on_train_end(self,args,state,control,**kwargs):
   write_json(self.path.with_name('trainer_state_audit.json'),dict(global_step=state.global_step,best_metric=state.best_metric,best_model_checkpoint=state.best_model_checkpoint,log_history=state.log_history))
 for seed in ([13] if args.task=='smoke' else args.seeds):
  if args.task!='smoke' and completed('LoRA_r16',seed):continue
  seedall(seed);dest=out/f'lora_r16_seed{seed}'
  if dest.exists():
   archive=dest.with_name(dest.name+'_interrupted_'+str(time.time_ns()));dest.rename(archive);note('Retained previous incomplete training directory: '+str(archive))
  dest.mkdir();note('Starting '+args.task+' seed '+str(seed));torch.cuda.empty_cache();torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter()
  steps=2 if args.task=='smoke' else 1000;interval=2 if args.task=='smoke' else 50
  train_inputs=data['train'][:16] if args.task=='smoke' else data['train']
  selection_inputs=data['selection'][:8] if args.task=='smoke' else data['selection']
  fitted=pipe.fit(inputs=[torch.tensor(x[None,:]) for x in train_inputs],validation_inputs=[torch.tensor(x[None,:]) for x in selection_inputs],prediction_length=72,context_length=336,min_past=336,finetune_mode='lora',lora_config=LoraConfig(r=16,lora_alpha=32,lora_dropout=.05,bias='none',target_modules=['output_patch_embedding.output_layer','self_attention.q','self_attention.o','self_attention.v','self_attention.k']),learning_rate=1e-5,num_steps=steps,batch_size=4,output_dir=dest,seed=seed,data_seed=seed,gradient_accumulation_steps=8,optim='adamw_torch_fused',weight_decay=0.,lr_scheduler_type='linear',warmup_steps=0,max_grad_norm=1.,bf16=True,fp16=False,eval_strategy='steps',eval_steps=interval,save_strategy='steps',save_steps=interval,save_total_limit=1,load_best_model_at_end=True,metric_for_best_model='eval_loss',greater_is_better=False,logging_steps=1 if args.task=='smoke' else 25,report_to='none',callbacks=[AuditCallback(dest/'training_audit.json')])
  torch.cuda.synchronize();seconds=time.perf_counter()-start;memory=torch.cuda.max_memory_allocated()
  if args.task=='smoke':
   pred=chronos_predict(fitted,data['selection'][:2,:336]);np.save(out/'smoke_validation_forecasts.npy',pred)
   write_json(dest/'runtime.json',dict(training_seconds=seconds,peak_GPU_allocated_bytes=memory,smoke_only=True))
   note('SMOKE PASSED: 2 training steps, validation, checkpoint saving and inference. This is not a scientific result.');raise SystemExit(0)
  start=time.perf_counter();pred=chronos_predict(fitted,data['evaluation'][:,:336]);torch.cuda.synchronize();inf=time.perf_counter()-start
  report_predictions(pred,'LoRA_r16',seed);(dest/'runtime.json').write_text(json.dumps(dict(training_seconds=seconds,inference_seconds=inf,peak_GPU_allocated_bytes=memory),indent=2));mark_completed('LoRA_r16',seed,[dest/'training_audit.json',dest/'runtime.json',dest/'trainer_state_audit.json']);summarize();note('Completed LoRA seed '+str(seed));del fitted,pred;gc.collect();torch.cuda.empty_cache()

if args.task=='gru':
 protocol['packages']=versions;guard_protocol()
 train=data['train'];val=data['selection'];evaluation=data['evaluation'];mu=float(train[:,:336].mean());sd=float(train[:,:336].std());assert sd>0
 configurations=[dict(name='32_huber',hidden=32,dropout=.1,lr=.001,loss='huber'),dict(name='64_huber',hidden=64,dropout=.2,lr=.0005,loss='huber'),dict(name='64_mse',hidden=64,dropout=.1,lr=.0005,loss='mse')]
 class GRU(nn.Module):
  def __init__(self,c):super().__init__();self.gru=nn.GRU(1,c['hidden'],batch_first=True);self.drop=nn.Dropout(c['dropout']);self.head=nn.Linear(c['hidden'],72)
  def forward(self,x):_,h=self.gru(x);return self.head(self.drop(h[-1]))
 for C in [168,336]:
  for seed in args.seeds:
   name=f'GRU_targetonly_C{C}'
   if completed(name,seed):continue
   note('Starting GRU context '+str(C)+' seed '+str(seed));bests=[];runtimes=[]
   for config in configurations:
    note('GRU candidate '+config['name']);seedall(seed);net=GRU(config).to(device);opt=torch.optim.AdamW(net.parameters(),lr=config['lr'],weight_decay=0.);lossfn=nn.HuberLoss(delta=1.) if config['loss']=='huber' else nn.MSELoss()
    x=torch.tensor((train[:,336-C:336]-mu)/sd).unsqueeze(-1);y=torch.tensor((train[:,336:]-mu)/sd);vx=torch.tensor((val[:,336-C:336]-mu)/sd).unsqueeze(-1).to(device);vy=torch.tensor((val[:,336:]-mu)/sd).to(device)
    loader=DataLoader(TensorDataset(x,y),batch_size=64,shuffle=True,generator=torch.Generator().manual_seed(seed));best=np.inf;stale=0;state=None;history=[];start=time.perf_counter();torch.cuda.reset_peak_memory_stats()
    for epoch in range(60):
     net.train()
     for xx,yy in loader:
      opt.zero_grad();loss=lossfn(net(xx.to(device)),yy.to(device));loss.backward();nn.utils.clip_grad_norm_(net.parameters(),1.);opt.step()
     net.eval()
     with torch.no_grad():score=float((net(vx)[:,[23,47,71]]-vy[:,[23,47,71]]).abs().mean().cpu())*sd
     history.append(dict(epoch=epoch+1,validation_endpoint_MAE=score))
     if epoch==0 or (epoch+1)%10==0:note('GRU epoch '+str(epoch+1)+' validation MAE '+str(round(score,4)))
     if score<best:best=score;stale=0;state={k:v.detach().cpu().clone() for k,v in net.state_dict().items()}
     else:stale+=1
     if stale>=8:break
    torch.cuda.synchronize();runtimes.append(dict(config=config,training_seconds=time.perf_counter()-start,peak_GPU_allocated_bytes=torch.cuda.max_memory_allocated(),epochs=len(history),best_validation_MAE=best))
    bests.append((best,config,state));pd.DataFrame(history).to_csv(out/f'GRU_C{C}_{config["name"]}_seed{seed}_history.csv',index=False)
    del net;gc.collect();torch.cuda.empty_cache()
   write_json(out/f'GRU_C{C}_seed{seed}_training_runtime.json',runtimes)
   best,config,state=min(bests,key=lambda x:x[0]);net=GRU(config).to(device);net.load_state_dict(state);net.eval();pred=[]
   with torch.no_grad():
    for i in range(0,len(evaluation),128):
     x=torch.tensor((evaluation[i:i+128,336-C:336]-mu)/sd).unsqueeze(-1).to(device);pred.append(net(x).float().cpu().numpy()*sd+mu)
   report_predictions(np.concatenate(pred),f'GRU_targetonly_C{C}',seed);torch.save(state,out/f'GRU_C{C}_seed{seed}.pt');(out/f'GRU_C{C}_seed{seed}_selection.json').write_text(json.dumps(dict(config=config,validation_MAE=best,training_mean=mu,training_SD=sd,seed=seed,context=C,selection='validation only; test never used'),indent=2));mark_completed(name,seed,[out/f'GRU_C{C}_seed{seed}.pt',out/f'GRU_C{C}_seed{seed}_selection.json',out/f'GRU_C{C}_seed{seed}_training_runtime.json']);summarize();note('Completed '+name+' seed '+str(seed));del net;gc.collect();torch.cuda.empty_cache()
summarize()
note('Completed '+args.task+'. Return the entire gpu_results_v3 folder, including all fixed seeds.')
