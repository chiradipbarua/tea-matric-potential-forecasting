"""Synthetic arithmetic tests only; these are not field observations/results."""
import unittest
import numpy as np
import pandas as pd
from metrics import point_metrics,interval_metrics,confusion_metrics,conformal_expansion,joint_block_mae_difference

class ScoringTests(unittest.TestCase):
    def test_point_identity_and_negative_r2(self):
        a=point_metrics([0,1,2],[0,1,2],[1,1,1]);self.assertEqual(a['R2'],1);self.assertEqual(a['MSE_skill'],1)
        self.assertLess(point_metrics([0,1,2],[2,1,0])['R2'],0)
        self.assertTrue(np.isnan(point_metrics([1,1],[1,1])['R2']))
    def test_undefined_precision(self):
        a=confusion_metrics([0,1],[0,0]);self.assertTrue(np.isnan(a['precision']));self.assertEqual(a['FN'],1)
    def test_interval_score(self):
        a=interval_metrics([3],[0],[1],[2]);self.assertEqual(a['interval_score'],12);self.assertEqual(a['coverage'],0)
        self.assertAlmostEqual(a['WIS'],(1+1.2)/1.5)
    def test_small_calibration_requires_infinite_score(self):
        self.assertTrue(np.isinf(conformal_expansion([1],[0],[2])))
    def test_joint_calendar_and_pairing(self):
        f=pd.DataFrame({'origin_timestamp':np.repeat(pd.date_range('2000-01-01',periods=12,freq='h'),2),'plot_id':['A','B']*12,'observed':0.,'predicted':1.,'reference':2.})
        a=joint_block_mae_difference(f,block_hours=4,replicates=30)
        self.assertEqual(a['difference'],-1);self.assertEqual(a['lower'],-1);self.assertEqual(a['upper'],-1)
        with self.assertRaises(ValueError):joint_block_mae_difference(pd.concat([f,f.iloc[:1]]),block_hours=4)

if __name__=='__main__':unittest.main()
